/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cs444project.presentation;


import java.util.*;
import CS444Wu.domain.*;
import javax.swing.table.AbstractTableModel;

/**
 *
 * @author jason
 */
public class WorkoutTableModel extends AbstractTableModel {
    
    private String[] columnNames = {"Workout Name", "Workout Type", "Date", "Duration", "Sets", "Reps"};
    
    private List<Workout> workouts = new LinkedList<Workout>();
    
    public void setWorkouts(List<Workout> workouts) {
        this.workouts = workouts;
    }

    @Override
    public int getRowCount() {
        return workouts.size();
    }

    @Override
    public int getColumnCount() {
        return columnNames.length;
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        Workout workout = workouts.get(rowIndex);
        switch (columnIndex) {
            case 0:
                return workout.getWorkoutName();
            case 1:
                return workout.getWorkoutType();
            case 2:
                return workout.getDate();
            case 3:
                return workout.getDuration();
            case 4:
                return workout.getSets();
            case 5:
                return workout.getReps();
        }
        return "";
    }
}
