/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cs444project;

import cs444project.presentation.*;
/**
 *
 * @author jason
 */
public class CS444Project {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        LoginUI loginUI = new LoginUI();
        loginUI.setVisible(true);
        //loginUI.show();
        
        /*CreateAccountUI createAccount = new CreateAccountUI();
        createAccount.setVisible(true);
        createAccount.show();
        
        
        CreateDailyEntryUI createDailyEntry = new CreateDailyEntryUI();
        createDailyEntry.setVisible(true);
        createDailyEntry.show();
        
        LookupWorkoutUI lookupWorkout = new LookupWorkoutUI();
        lookupWorkout.setVisible(true);
        lookupWorkout.show();
        
        UpdateEntryUI updateEntry = new UpdateEntryUI();
        updateEntry.setVisible(true);
        updateEntry,show();
        
        DeleteEntryUI deleteEntry = new DeleteEntryUI();
        deleteEntry.setVisible(true);
        deleteEntry.show();
        
        DeleteAccountUI deleteAccount = new DeleteAccountUI();
        deleteAccount.setVisible(true);
        deleteAccount.show();*/
        
    }
    
}
