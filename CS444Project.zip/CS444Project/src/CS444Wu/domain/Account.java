/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CS444Wu.domain;
import java.util.LinkedList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
/**
 *
 * @author jason
 */
public class Account {
    
    private String firstName = " ";
    private String lastName = " ";
    private String username = " ";
    private String password = " ";
    private String email = " ";
    private int id;
    private Login login = null;

    private final int USERNAME_LENGTH = 10;
    private final int PASSWORD_LENGTH = 8;
    
    private List<Workout> workouts = new LinkedList<Workout>();
    private int nextId;
    
    public Workout add(Workout workout) {
        workout.setId(nextId++);
        workouts.add(workout);
        return workout;
    }
    
    public boolean validate() {
        char firstNameCh = firstName.charAt(0);
        char lastNameCh = lastName.charAt(0);
        char passwordCh = password.charAt(0);
        
        if (firstNameCh != Character.toUpperCase(firstNameCh) || firstName.equals("")) {
            return false;
        }
        if (lastNameCh != Character.toUpperCase(lastNameCh) || lastName.equals("")) {
            return false;
        }
        if (username.length() < USERNAME_LENGTH || username.equals("")) {
            return false;
        }
        if (password.length() < PASSWORD_LENGTH || password.equals("") || passwordCh != Character.toUpperCase(passwordCh)) {
            return false;
        }
        if (email == null || email.equals("") || email.contains("@")) {
            return false;
        }
        
        return true;
    }
    
    
    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Login getLogin() {
        return login;
    }

    public void setLogin(Login login) {
        this.login = login;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
    
    public List<Workout> getWorkouts() {
        return workouts;
    }
    
}
