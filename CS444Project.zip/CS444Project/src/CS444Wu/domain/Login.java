/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CS444Wu.domain;

import java.lang.*;

/**
 *
 * @author jason
 */
public class Login {
    private String username = " ";
    private String password = " ";
    
    private final int PASSWORD_LENGTH = 8;
    private final int USERNAME_LENGTH = 10;

    //boolean letter = false;
    //boolean number = false;

    
    public boolean validate() {    
        //char uch = username.charAt(0);
        char passwordCh = password.charAt(0);
        
        if (username == null || username.length() < USERNAME_LENGTH || username.equals("")) {
            return false;
        }
        if (password == null || password.length() < PASSWORD_LENGTH || password.equals("") || passwordCh != Character.toUpperCase(passwordCh)) {
            return false;
        }
        return true;
    }
    
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (! (obj instanceof Login)) {
            return false;
        }
        Login login = (Login)obj;
        if (!this.username.equals(login.getUsername())) {
            return false;
        }
        if (!this.password.equals(login.getPassword())) {
            return false;
        }
        return true;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
    
    
    
    
}
