/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CS444Wu.domain;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 *
 * @author jason
 */
public class Workout {
    
    private String workoutName = " ";
    private String workoutType = " ";
    private String date = " ";
    private String sets = " ";
    private String reps = " ";
    private String duration = " ";
    private int id;
    
    public boolean validate() { 
        
        if (workoutName == null || workoutName.equals("")) {
            return false;
        }
        if (workoutType == null || workoutType.equals("")) {
            return false;
        }
        if (!isValidDate(date)) {
            return false;
        }
        if (duration == null || duration.equals("")) { 
            return false;
        }
        if (sets == null || sets.equals("")) {
            return false;
        }
        if (reps == null || reps.equals("")) {
            return false;
        }
        
        return true;
        
    }

    public static boolean isValidDate(String d) { 
        String regex = "^(1[0-2]|0[1-9])/(3[01]|[12][0-9]|0[1-9])/[0-9]{4}$"; 
        Pattern pattern = Pattern.compile(regex); 
        Matcher matcher = pattern.matcher((CharSequence)d); 
        return matcher.matches(); 
    } 
    
    
    public String getWorkoutName() {
        return workoutName;
    }

    public void setWorkoutName(String workoutName) {
        this.workoutName = workoutName;
    }

    public String getWorkoutType() {
        return workoutType;
    }

    public void setWorkoutType(String workoutType) {
        this.workoutType = workoutType;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getDuration() {
        return duration;
    }

    public void setDuration(String duration) {
        this.duration = duration;
    }
    
    public String getSets() {
        return sets;
    }

    public void setSets(String sets) {
        this.sets = sets;
    }

    public String getReps() {
        return reps;
    }

    public void setReps(String reps) {
        this.reps = reps;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
    
    
    
    
}
