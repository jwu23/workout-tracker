/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CS444Wu.service;

import CS444Wu.domain.*;
import java.util.List;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author jason
 */
public class AccountSvcCacheImplTest {
    
    public AccountSvcCacheImplTest() {
    }

    @Test
    public void testCRUD() {
        
        AccountSvcCacheImpl impl = new AccountSvcCacheImpl();
        List<Account> accounts = impl.retrieveAll();
        assertEquals(accounts.size(), 0);
        
        Account account = new Account();
        account.setFirstName("Jason");
        account.setLastName("Wu");
        Login login = new Login();
        login.setUsername("jasonnn1623");
        login.setPassword("Jasonwu123");
        account.setLogin(login);
        
        account = impl.create(account);
        assertNotNull(account);
        assertNotEquals(account.getId(), 0);
        
        accounts = impl.retrieveAll();
        assertEquals(accounts.size(), 1);
        
        account.setFirstName("John");
        account = impl.update(account);
        accounts = impl.retrieveAll();
        assertEquals(accounts.size(), 1);
        assertEquals(account.getFirstName(), "John");
        
        account = impl.delete(account);
        assertEquals(accounts.size(), 0);
        
        
        Account account1 = new Account();
        account1.setFirstName("Jason");
        account1.setLastName("Wu");
        Login login1 = new Login();
        login1.setUsername("Jasonwu1623");
        login1.setPassword("Jasonwu123");
        account1.setLogin(login1);
        account1 = impl.create(account1);
        assertNotNull(account1);
        
        Account account2 = new Account();
        account2.setFirstName("Gil");
        account2.setLastName("Lemar");
        Login login2 = new Login();
        login2.setUsername("Gillemar1234");
        login2.setPassword("Gillemar2423");
        account2.setLogin(login2);
        account2 = impl.create(account2);
        assertNotNull(account2);
        Login login3 = new Login();
        login3.setUsername("blah");
        login3.setPassword("yada");
        Account authenAccount = impl.authenticate(login3);
        assertNull(authenAccount);
        login3.setUsername("Jasonwu1623");
        authenAccount = impl.authenticate(login3);
        assertNull(authenAccount);
        login3.setPassword("Jasonwu123");
        authenAccount = impl.authenticate(login3);
        assertNull(authenAccount);
        login3.setUsername("Gillemar1234");
        authenAccount = impl.authenticate(login3);
        assertNull(authenAccount);
        login3.setPassword("Gillemar2423");
        authenAccount = impl.authenticate(login3);
        assertNull(authenAccount);
        
    }
   
    
}
