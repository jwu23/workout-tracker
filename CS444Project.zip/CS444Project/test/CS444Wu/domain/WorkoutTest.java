/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CS444Wu.domain;

import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author jason
 */
public class WorkoutTest {
    
    public WorkoutTest() {
    }

    @Test
    public void testValidate() {
        
        Workout workout = new Workout();
        boolean result = workout.validate();
        assertFalse(result);
        
        workout.setWorkoutName("Bench Press");
        result = workout.validate();
        assertFalse(result);
        
        workout.setWorkoutType("Chest");
        result = workout.validate();
        assertFalse(result);
        
        workout.setDate("10/10/19");
        result = workout.validate();
        assertFalse(result);
        
        workout.setDuration("60 minutes");
        result = workout.validate();
        assertFalse(result);
        
        workout.setReps("10");
        result = workout.validate();
        assertFalse(result);
        
        workout.setSets("5");
        result = workout.validate();
        assertTrue(result);
        
        
        
    }
    
}
