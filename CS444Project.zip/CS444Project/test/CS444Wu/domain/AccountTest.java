/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CS444Wu.domain;

import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author jason
 */
public class AccountTest {
    
    public AccountTest() {
    }

    @Test
    public void testValidate() {
        Account account = new Account();
        boolean result = account.validate();
        assertFalse(result);
        account.setFirstName("Jason");
        result = account.validate();
        assertFalse(result);
        
        account.setLastName("Wu");
        result = account.validate();
        assertFalse(result);
        
        account.setUsername("jasonnn1623");
        result = account.validate();
        assertFalse(result);
        
        account.setPassword("Jasonwu123");
        result = account.validate();
        assertFalse(result);
        
        account.setEmail("jwu001@regis.edu");
        result = account.validate();
        assertFalse(result);
        
        Login login = new Login();
        login.setUsername("jas1623");
        login.setPassword("Jasonwu123");
        account.setLogin(login);
        result = account.validate();
        assertTrue(result);
    }
    
}
